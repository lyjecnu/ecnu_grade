import matplotlib.pyplot as plt
import numpy as np
from grade import fdata


sum = {
        '3.9+':0,
        '3.8+':0,
        '3.7+':0,
        '3.6+':0,
        '3.5+':0,
        '3.4+':0,
        '3.3+':0,
        '3.2+':0,
        '3.1+':0,
        '3.0+':0,
    }
        

epochs = 1000
for t in range(epochs):
    dict =  fdata(100,10,65,15,6,2)
    for key,value in dict.items():
        #print(value)
        sum[key] = sum[key] + value
 
for key,value in sum.items():
    sum[key] = value / epochs
    #print(sum[key])



grade = list(sum.keys())
percent = list(sum.values())

plt.plot(grade,percent)
plt.grid(True)
plt.xlabel('grade')
plt.ylabel('percentage')


for i, value in enumerate(percent):
    plt.text(grade[i], value, f'{value}', ha='center', va='bottom')

plt.savefig('grade_percent.png')
plt.show()